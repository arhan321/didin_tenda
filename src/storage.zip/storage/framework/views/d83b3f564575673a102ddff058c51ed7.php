<?php $__env->startSection('section'); ?>

  <!-- ======= Menu Section ======= -->
  <section id="menu" class="menu section-bg">
    <div class="container" data-aos="fade-up">
      <div class="section-title">
        <h2><?php echo e(trans('panel.frontend.menu.menu_1')); ?></h2>
        <p><?php echo e(trans('panel.frontend.menu.menu_2')); ?></p>
      </div>

      <div class="row" data-aos="fade-up" data-aos-delay="100">
        <div class="col-lg-12 d-flex justify-content-center">
            <ul id="menu-flters">
                <li data-filter="*" class="filter-active">All</li>
                <!-- filter berdasarkan category pada model product -->
                <?php $__empty_1 = true; $__currentLoopData = \App\Models\Product::CATEGORY_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li data-filter=".filter-<?php echo e(strtolower(str_replace(' ', '-', $key))); ?>"><?php echo e($value); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li><?php echo e(trans('panel.frontend.menu.if_error_category')); ?></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
      <div class="row menu-container" data-aos="fade-up" data-aos-delay="200">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-6 menu-item filter-<?php echo e(strtolower(str_replace(' ', '-', $p->category))); ?>">
              <img src="<?php echo e($p->getFirstMediaUrl('image', 'preview')); ?>" class="menu-img" alt="<?php echo e($p->name); ?>"/>
              <div class="menu-content">
                <a href="#"><?php echo e($p->name); ?></a><span>Rp. <?php echo e(number_format($p->price, 0, ',', '.')); ?></span>
              </div>
              <div class="menu-ingredients">
                <?php echo e($p->description); ?>

              </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-lg-12">
                <p><?php echo e(trans('panel.frontend.menu.if_error_menu')); ?></p>
            </div>
        <?php endif; ?>
      </div>
    </div>
  </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/frontend/menu.blade.php ENDPATH**/ ?>