<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.booking.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.bookings.update", [$booking->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="nama_customer"><?php echo e(trans('cruds.booking.fields.nama_customer')); ?></label>
                <input class="form-control <?php echo e($errors->has('nama_customer') ? 'is-invalid' : ''); ?>" type="text" name="nama_customer" id="nama_customer" value="<?php echo e(old('nama_customer', $booking->nama_customer)); ?>" required>
                <?php if($errors->has('nama_customer')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('nama_customer')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.title_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="jumlah_orang"><?php echo e(trans('cruds.booking.fields.jumlah_orang')); ?></label>
                <input class="form-control <?php echo e($errors->has('jumlah_orang') ? 'is-invalid' : ''); ?>" type="text" name="jumlah_orang" id="jumlah_orang" value="<?php echo e(old('jumlah_orang', $booking->jumlah_orang)); ?>" required>
                <?php if($errors->has('jumlah_orang')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('jumlah_orang')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.jumlah_orang_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="start_book"><?php echo e(trans('cruds.booking.fields.start_book')); ?></label>
                <input class="form-control datetime <?php echo e($errors->has('start_book') ? 'is-invalid' : ''); ?>" type="text" name="start_book" id="start_book" value="<?php echo e(old('start_book', $booking->start_book)); ?>" required>
                <?php if($errors->has('start_book')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('start_book')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.start_book_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="finish_book"><?php echo e(trans('cruds.booking.fields.finish_book')); ?></label>
                <input class="form-control datetime <?php echo e($errors->has('finish_book') ? 'is-invalid' : ''); ?>" type="text" name="finish_book" id="finish_book" value="<?php echo e(old('finish_book', $booking->finish_book)); ?>" required>
                <?php if($errors->has('finish_book')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('finish_book')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.finish_book_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.booking.fields.category')); ?></label>
                <select class="form-control <?php echo e($errors->has('category') ? 'is-invalid' : ''); ?>" name="category" id="category" required>
                    <option value disabled <?php echo e(old('category', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Booking::CATEGORY_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('category', $booking->category) === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('category')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('category')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.category_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.booking.fields.status')); ?></label>
                <select class="form-control <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>" name="status" id="status">
                    <option value disabled <?php echo e(old('status', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Booking::STATUS_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('status', $booking->status) === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('status')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('status')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.status_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="table_id"><?php echo e(trans('cruds.booking.fields.table')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('table') ? 'is-invalid' : ''); ?>" name="table_id" id="table_id" required>
                    <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('table_id') ? old('table_id') : $booking->table->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($table); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('table')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('table')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.booking.fields.table_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/bookings/edit.blade.php ENDPATH**/ ?>