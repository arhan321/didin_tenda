<?php $__env->startSection( 'section'); ?>

<!-- ======= Gallery Section ======= -->

<section id="gallery" class="gallery">
    <div class="container" data-aos="fade-up">
      <div class="section-title">
        <h2><?php echo e(trans('panel.frontend.galery.galery_1')); ?></h2>
        <p><?php echo e(trans('panel.frontend.galery.galery_2')); ?></p>
      </div>
    </div>
    
   
    <div class="container-fluid" data-aos="fade-up" data-aos-delay="100">
      <div class="row g-0">
          <?php $__empty_1 = true; $__currentLoopData = $galery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="col-lg-3 col-md-4">
              <div class="gallery-item">
                  <?php if($g->getFirstMediaUrl('image', 'priview')): ?>
                      <a href="<?php echo e($g->getFirstMediaUrl('image', 'priview')); ?>" class="gallery-lightbox" data-gall="gallery-item">
                          <img src="<?php echo e($g->getFirstMediaUrl('image', 'priview')); ?>" alt="<?php echo e($g->title); ?>" class="img-fluid"/>
                      </a>
                  <?php else: ?>
                      <p>Error: Image not found</p>
                  <?php endif; ?>
              </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <div class="col-12">
                  <p>Error: No gallery items available</p>
              </div>
          <?php endif; ?>
      </div>
  </div>
  </section>
  <!-- End Gallery Section -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/frontend/galery.blade.php ENDPATH**/ ?>