<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('orderditempat_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.orderditempats.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.orderditempat.title_singular')); ?>

            </a>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.orderditempat.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-orderditempat">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.orderditempat.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.orderditempat.fields.nama_pemesan')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.orderditempat.fields.product')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.orderditempat.fields.price')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.orderditempat.fields.jam_pesan')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.orderditempat.fields.tanggal_pesan')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.orderditempat.fields.table')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.orderditempat.fields.status_bayar')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orderditempats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $orderditempat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($orderditempat->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($orderditempat->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($orderditempat->nama_pemesan ?? ''); ?>

                            </td>
                            <td>
                                <?php if(isset($orderditempat->product_details)): ?>
                                    <?php
                                        $productDetails = [];
                                        foreach ($orderditempat->product_details as $product) {
                                            $productDetails[] = $product['name'] . ' (Qty: ' . $product['qty'] . ')';
                                        }
                                        echo implode(', ', $productDetails);
                                    ?>
                                <?php endif; ?>
                            </td>
                            <td class="price-column">
                                <?php echo e('Rp ' . number_format($orderditempat->price ?? 0, 2, ',', '.')); ?>

                            </td>
                            <td>
                                <?php echo e($orderditempat->jam_pesan ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($orderditempat->tanggal_pesan ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(trans('cruds.table_information.table')); ?> <?php echo e($orderditempat->table_id ?? ''); ?>

                             </td>
                             <td>
                                <?php if($orderditempat->status_bayar == 'Belum bayar'): ?>
                                    <span class="status-unpaid"><?php echo e(App\Models\orderditempat::STATUS_SELECT['Belum_bayar'] ?? 'Belum bayar'); ?></span>
                                <?php elseif($orderditempat->status_bayar == 'Sudah bayar'): ?>
                                    <span class="status-selesai"><?php echo e(App\Models\orderditempat::STATUS_SELECT['Sudah_bayar'] ?? 'Sudah bayar'); ?></span>
                                <?php else: ?>
                                    <?php echo e(App\Models\Booking::STATUS_SELECT[$orderditempat->status] ?? ''); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('orderditempat_show')): ?>
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.orderditempats.show', $orderditempat->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('orderditempat_edit')): ?>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.orderditempats.edit', $orderditempat->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('orderditempat_delete')): ?>
                                    <form action="<?php echo e(route('admin.orderditempats.destroy', $orderditempat->id)); ?>" method="POST" class="delete-form" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-xs btn-danger delete-button" value="<?php echo e(trans('global.delete')); ?>">
                                    </form>
                                <?php endif; ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
    
    .status-unpaid {
        background-color: red;
        color: white;
        padding: 5px 10px;
        border-radius: 5px;
        font-weight: bold;
        margin: 5px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: background-color 0.3s, box-shadow 0.3s;
        display: inline-block;
    }

    .status-unpaid:hover {
        background-color: darkred;
        box-shadow: 0 6px 8px rgba(0, 0, 0, 0.2);
    }

    .status-selesai {
        background-color: green;
        color: white;
        padding: 5px 10px;
        border-radius: 5px;
        font-weight: bold;
        margin: 5px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        transition: background-color 0.3s, box-shadow 0.3s;
        display: inline-block;
    }

    .status-selesai:hover {
        background-color: darkgreen;
        box-shadow: 0 6px 8px rgba(0, 0, 0, 0.2);
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    $(function () {
        let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('orderditempat_delete')): ?>
        let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
        let deleteButton = {
            text: deleteButtonTrans,
            url: "<?php echo e(route('admin.orderditempats.massDestroy')); ?>",
            className: 'btn-danger',
            action: function (e, dt, node, config) {
                var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
                    return $(entry).data('entry-id')
                });

                if (ids.length === 0) {
                    alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

                    return
                }

                Swal.fire({
                    title: '<?php echo e(trans('global.areYouSure')); ?>',
                    text: '<?php echo e(trans('global.areYouSureDelete')); ?>',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: '<?php echo e(trans('global.delete')); ?>',
                    cancelButtonText: '<?php echo e(trans('global.cancel')); ?>'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            headers: {'x-csrf-token': _token},
                            method: 'POST',
                            url: config.url,
                            data: { ids: ids, _method: 'DELETE' }
                        })
                        .done(function () { location.reload() })
                    }
                })
            }
        }
        dtButtons.push(deleteButton)
        <?php endif; ?>

        $.extend(true, $.fn.dataTable.defaults, {
            orderCellsTop: true,
            order: [[ 1, 'desc' ]],
            pageLength: 100,
        });
        let table = $('.datatable-orderditempat:not(.ajaxTable)').DataTable({ buttons: dtButtons })
        $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
            $($.fn.dataTable.tables(true)).DataTable()
                .columns.adjust();
        });
    })

    $('.delete-button').on('click', function(e) {
        e.preventDefault();
        var form = $(this).closest('form');

        Swal.fire({
            title: '<?php echo e(trans('global.areYouSure')); ?>',
            text: '<?php echo e(trans('global.areYouSureDelete')); ?>',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: '<?php echo e(trans('global.delete')); ?>',
            cancelButtonText: '<?php echo e(trans('global.cancel')); ?>'
        }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/orderditempats/index.blade.php ENDPATH**/ ?>