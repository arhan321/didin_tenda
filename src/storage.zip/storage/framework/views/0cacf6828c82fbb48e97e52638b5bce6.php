<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tim_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.tims.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.tim.title_singular')); ?>

            </a>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.tim.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover datatable datatable-Tim">
                <thead>
                    <tr>
                        <th width="10"></th>
                        <th><?php echo e(trans('cruds.tim.fields.id')); ?></th>
                        <th><?php echo e(trans('cruds.tim.fields.name')); ?></th>
                        <th><?php echo e(trans('cruds.tim.fields.position')); ?></th>
                        <th><?php echo e(trans('cruds.tim.fields.status')); ?></th>
                        <th><?php echo e(trans('cruds.tim.fields.image')); ?></th>
                        <th>&nbsp;</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($tim->id); ?>">
                            <td></td>
                            <td><?php echo e($tim->id ?? ''); ?></td>
                            <td><?php echo e($tim->name ?? ''); ?></td>
                            <td><?php echo e(App\Models\Tim::POSITION[$tim->position] ?? ''); ?></td>
                            <td>
                                <span class="status-badge <?php echo e($tim->status == 'bekerja' ? 'badge-success' : 'badge-danger'); ?>">
                                    <?php echo e(App\Models\Tim::STATUS[$tim->status] ?? ''); ?>

                                </span>
                            </td>
                            <td>
                                <?php if($tim->image): ?>
                                    <a href="<?php echo e($tim->image->getUrl()); ?>" target="_blank" style="display: inline-block">
                                        <img src="<?php echo e($tim->image->getUrl('thumb')); ?>">
                                    </a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tim_show')): ?>
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.tims.show', $tim->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tim_edit')): ?>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.tims.edit', $tim->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tim_delete')): ?>
                                    <form class="delete-form" action="<?php echo e(route('admin.tims.destroy', $tim->id)); ?>" method="POST" style="display: inline-block;">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="button" class="btn btn-xs btn-danger delete-button"><?php echo e(trans('global.delete')); ?></button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .status-badge {
        font-size: 1em; 
        padding: 0.8em; 
    }
    .badge-success {
    background-color: green;
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
    font-weight: bold;
    }
    .badge-danger {
    background-color: red;
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
    font-weight: bold;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
        let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tim_delete')): ?>
        let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
        let deleteButton = {
            text: deleteButtonTrans,
            url: "<?php echo e(route('admin.tims.massDestroy')); ?>",
            className: 'btn-danger',
            action: function (e, dt, node, config) {
                var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
                    return $(entry).data('entry-id')
                });

                if (ids.length === 0) {
                    alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')
                    return
                }

                Swal.fire({
                    title: '<?php echo e(trans('global.areYouSure')); ?>',
                    text: "<?php echo e(trans('global.areYouSureDelete')); ?>",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: '<?php echo e(trans('global.confirmDelete')); ?>',
                    cancelButtonText: '<?php echo e(trans('global.cancel')); ?>'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            headers: {'x-csrf-token': _token},
                            method: 'POST',
                            url: config.url,
                            data: { ids: ids, _method: 'DELETE' }})
                            .done(function () { location.reload() })
                    }
                })
            }
        }
        dtButtons.push(deleteButton)
        <?php endif; ?>

        $.extend(true, $.fn.dataTable.defaults, {
            orderCellsTop: true,
            order: [[ 1, 'desc' ]],
            pageLength: 100,
        });
        let table = $('.datatable-Tim:not(.ajaxTable)').DataTable({ buttons: dtButtons })
        $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
            $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
        });

        $('.delete-button').click(function (e) {
            e.preventDefault();
            let form = $(this).closest('form');
            Swal.fire({
                title: '<?php echo e(trans('global.areYouSure')); ?>',
                text: "<?php echo e(trans('global.areYouSureDelete')); ?>",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: '<?php echo e(trans('global.confirmDelete')); ?>',
                cancelButtonText: '<?php echo e(trans('global.cancel')); ?>'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            })
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/tims/index.blade.php ENDPATH**/ ?>