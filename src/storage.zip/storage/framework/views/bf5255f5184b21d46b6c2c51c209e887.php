<?php $__env->startSection('content'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('booking_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.bookings.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.booking.title_singular')); ?>

            </a>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.booking.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover datatable datatable-Booking">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.nama_customer')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.jumlah_orang')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.start_book')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.finish_book')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.category')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.table')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.customer_email')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.phone')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.total_price')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.booking.fields.status')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($booking->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($booking->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($booking->nama_customer ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($booking->jumlah_orang ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($booking->start_book ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($booking->finish_book ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(App\Models\Booking::CATEGORY_SELECT[$booking->category] ?? ''); ?>

                            </td>
                            <td>
                               <?php echo e(trans('cruds.table_information.table')); ?> <?php echo e($booking->table_id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($booking->customer_email ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($booking->phone ?? ''); ?>

                            </td>
                            <td>
                                Rp <?php echo e(number_format($booking->total_price, 2)); ?>

                            </td>
                            <td>
                                <?php if($booking->status == 'Cancel'): ?>
                                    <span class="status-cancel"><?php echo e(App\Models\Booking::STATUS_SELECT[$booking->status] ?? ''); ?></span>
                                <?php elseif($booking->status == 'Booking'): ?>
                                    <span class="status-booking"><?php echo e(App\Models\Booking::STATUS_SELECT[$booking->status] ?? ''); ?></span>
                                <?php elseif($booking->status == 'Selesai'): ?>
                                    <span class="status-selesai"><?php echo e(App\Models\Booking::STATUS_SELECT[$booking->status] ?? ''); ?></span>
                                <?php else: ?>
                                    <?php echo e(App\Models\Booking::STATUS_SELECT[$booking->status] ?? ''); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('booking_show')): ?>
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.bookings.show', $booking->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('booking_edit')): ?>
                                    <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.bookings.edit', $booking->id)); ?>">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('booking_delete')): ?>
                                    <form action="<?php echo e(route('admin.bookings.destroy', $booking->id)); ?>" method="POST" class="delete-form" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                    </form>
                                <?php endif; ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<style>
.status-cancel {
    background-color: red;
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
    font-weight: bold;
}

.status-booking {
    background-color: green;
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
    font-weight: bold;
}

.status-selesai {
    background-color: green;
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
    font-weight: bold; /* Atur warna atau gaya lainnya sesuai kebutuhan */
}

</style>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    $(function () {
        let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('booking_delete')): ?>
        let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
        let deleteButton = {
            text: deleteButtonTrans,
            url: "<?php echo e(route('admin.bookings.massDestroy')); ?>",
            className: 'btn-danger',
            action: function (e, dt, node, config) {
                var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
                    return $(entry).data('entry-id')
                });

                if (ids.length === 0) {
                    Swal.fire({
                        title: '<?php echo e(trans('global.datatables.zero_selected')); ?>',
                        icon: 'warning',
                    })

                    return
                }

                Swal.fire({
                    title: '<?php echo e(trans('global.areYouSure')); ?>',
                    text: "<?php echo e(trans('global.areYouSureDelete')); ?>",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: '<?php echo e(trans('global.confirmDelete')); ?>',
                    cancelButtonText: '<?php echo e(trans('global.cancel')); ?>'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $.ajax({
                            headers: {'x-csrf-token': _token},
                            method: 'POST',
                            url: config.url,
                            data: { ids: ids, _method: 'DELETE' }
                        }).done(function () { location.reload() })
                    }
                })
            }
        }
        dtButtons.push(deleteButton)
        <?php endif; ?>

        $.extend(true, $.fn.dataTable.defaults, {
            orderCellsTop: true,
            order: [[ 1, 'desc' ]],
            pageLength: 100,
        });
        let table = $('.datatable-Booking:not(.ajaxTable)').DataTable({ buttons: dtButtons })
        $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
            $($.fn.dataTable.tables(true)).DataTable()
                .columns.adjust();
        });
    })

    $('.delete-form').on('submit', function(e) {
        e.preventDefault();
        let form = this;
        Swal.fire({
            title: '<?php echo e(trans('global.areYouSure')); ?>',
            text: "<?php echo e(trans('global.areYouSureDelete')); ?>",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: '<?php echo e(trans('global.confirmDelete')); ?>',
            cancelButtonText: '<?php echo e(trans('global.cancel')); ?>'
        }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
            }
        })
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/bookings/index.blade.php ENDPATH**/ ?>