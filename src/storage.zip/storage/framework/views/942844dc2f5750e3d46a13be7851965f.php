<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.history_booking.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-history_booking">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            <?php echo e(trans('cruds.history_booking.fields.id')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.history_booking.fields.nama_customer')); ?>

                        </th>
                        
                        <th>
                            <?php echo e(trans('cruds.history_booking.fields.start_book')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.history_booking.fields.finish_book')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.history_booking.fields.phone')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.history_booking.fields.customer_email')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.history_booking.fields.table')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.history_booking.fields.jumlah_orang')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.history_booking.fields.total_price')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.history_booking.fields.status')); ?>

                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($b->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($b->id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($b->nama_customer ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($b->start_book ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($b->finish_book ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($b->phone ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($b->customer_email ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e(trans('cruds.table_information.table')); ?> <?php echo e($b->table_id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($b->jumlah_orang ?? ''); ?>

                            </td>
                            <td>
                                Rp <?php echo e(number_format($b->total_price, 2)); ?>

                            </td>
                            <td>
                                <?php if($b->status == 'Cancel'): ?>
                                    <span class="status-cancel"><?php echo e(App\Models\Booking::STATUS_SELECT[$b->status] ?? ''); ?></span>
                                <?php elseif($b->status == 'Booking'): ?>
                                    <span class="status-booking"><?php echo e(App\Models\Booking::STATUS_SELECT[$b->status] ?? ''); ?></span>
                                <?php elseif($b->status == 'Selesai'): ?>
                                    <span class="status-selesai"><?php echo e(App\Models\Booking::STATUS_SELECT[$b->status] ?? ''); ?></span>
                                <?php else: ?>
                                    <?php echo e(App\Models\Booking::STATUS_SELECT[$b->status] ?? ''); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                             

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<style>
    .status-cancel {
    background-color: red;
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
    font-weight: bold;
}

.status-booking {
    background-color: green;
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
    font-weight: bold;
}

.status-selesai {
    background-color: green;
    color: white;
    padding: 5px 10px;
    border-radius: 5px;
    font-weight: bold; /* Atur warna atau gaya lainnya sesuai kebutuhan */
}
</style>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
// <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('order_delete')): ?>
//   let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
//   let deleteButton = {
//     text: deleteButtonTrans,
//     url: "<?php echo e(route('admin.prices.massDestroy')); ?>",
//     className: 'btn-danger',
//     action: function (e, dt, node, config) {
//       var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
//           return $(entry).data('entry-id')
//       });

//       if (ids.length === 0) {
//         alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

//         return
//       }

//       if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
//         $.ajax({
//           headers: {'x-csrf-token': _token},
//           method: 'POST',
//           url: config.url,
//           data: { ids: ids, _method: 'DELETE' }})
//           .done(function () { location.reload() })
//       }
//     }
//   }
//   dtButtons.push(deleteButton)
// <?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-history_booking:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/history_bookings/index.blade.php ENDPATH**/ ?>